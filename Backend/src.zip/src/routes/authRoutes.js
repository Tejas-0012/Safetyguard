const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const {
  register,
  login,
  checkPhone,          // ✅ ADD THIS
  getUserByPhone,      // ✅ ADD THIS
  verifyFirebase,
} = require('../controllers/authController');

// ============ VALIDATION RULES ============

const validateRegister = [
  body('name').notEmpty().withMessage('Name is required'),
  body('phone').notEmpty().withMessage('Phone number is required'),
  body('email').isEmail().withMessage('Please provide a valid email'),
  body('password')
    .isLength({ min: 6 })
    .withMessage('Password must be at least 6 characters'),
];

const validateLogin = [
  body('email').isEmail().withMessage('Please provide a valid email'),
  body('password').notEmpty().withMessage('Password is required'),
];

// ============ ROUTES ============

// Auth routes
router.post('/register', validateRegister, register);
router.post('/login', validateLogin, login);
router.post('/verify-firebase', verifyFirebase);

// ✅ ADD THESE ROUTES
router.post('/check-phone', checkPhone);        // Check if phone exists
router.post('/user-by-phone', getUserByPhone);  // Get user by phone

module.exports = router;